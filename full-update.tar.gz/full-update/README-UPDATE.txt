========================================
  财务日历 - 完整更新包
========================================

使用方法：
1. 把所有文件覆盖到你的项目目录（如 C:\cal\calendar-app-main\）
   保持相同的目录结构即可

2. 然后按以下步骤打包 EXE：

   cd C:\cal\calendar-app-main\.next
   rmdir /s /q standalone
   tar -xzf standalone-build.tar.gz
   cd C:\cal\calendar-app-main
   npm run electron:pack:win

如果创建账号还是失败：
1. 打开应用后按 F12 打开开发者工具
2. 在浏览器地址栏输入：http://127.0.0.1:17432/api/health/db
3. 把页面显示的 JSON 内容发给我，我就能看出问题在哪

更新的文件列表：
- electron/main.js        → 设置 Prisma 引擎路径 + 自动建表
- src/lib/db.ts           → 自动创建 SQLite 表结构
- src/app/api/auth/setup/route.ts  → 等待数据库初始化 + 详细错误
- src/app/api/health/db/route.ts   → 新增：数据库诊断 API
- src/components/calendar/SetupPage.tsx  → 显示具体错误信息
- src/components/calendar/LoginDialog.tsx → 显示具体错误信息
- prisma/schema.sqlite.prisma  → 多平台引擎支持
