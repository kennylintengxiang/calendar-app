========================================
  财务日历 - 完整更新包 (v3)
========================================

重要：这次更新修复了错误信息被吞掉的问题！
如果创建账号还是失败，现在页面会显示具体的错误原因。

使用方法：
1. 把所有文件覆盖到你的项目目录（如 C:\cal\calendar-app-main\）
2. 然后按以下步骤打包 EXE：

   cd C:\cal\calendar-app-main\.next
   rmdir /s /q standalone
   tar -xzf standalone-build.tar.gz
   cd C:\cal\calendar-app-main
   npm run electron:pack:win

如果创建账号还是失败：
- 页面上现在会显示具体的错误原因（不再是笼统的"设置失败"）
- 请截图或复制那个错误信息发给我
- 或者按 F12 打开开发者工具，在地址栏输入：http://127.0.0.1:17432/api/health/db
